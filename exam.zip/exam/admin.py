class Admin:
    def __init__(self, pinCode):
        self.pinCode=pinCode
